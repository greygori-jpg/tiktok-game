const socket = io();
const $ = id => document.getElementById(id);
const cardsEl = $("cards");

for (let i = 1; i <= 10; i++) {
  const card = document.createElement("div");
  card.className = "card";
  card.id = `card-${i}`;
  card.innerHTML = `<span class="symbol">✦</span>`;
  cardsEl.appendChild(card);
}

socket.on("connect", () => $("connection").textContent = "Игровой сервер подключён");
socket.on("disconnect", () => $("connection").textContent = "Нет связи с игровым сервером");
socket.on("game:state", state => {
  $("activeName").textContent = state.active ? "@" + state.active.username : "Ожидание игрока";
  $("attempts").textContent = `${state.active?.attempts || 0}/10`;
  $("progressText").textContent = `${state.active?.progress || 0}/10`;
  $("progressBar").style.width = `${(state.active?.progress || 0) * 10}%`;
  $("message").textContent = state.lastMessage || "";

  for (let i = 1; i <= 10; i++) {
    const el = $(`card-${i}`);
    el.className = "card";
    el.querySelector(".symbol").textContent = "✦";
    const card = state.cards.find(c => c.position === i);
    if (card?.status === "opened") {
      el.classList.add("opened");
      el.querySelector(".symbol").textContent = "✓";
    } else if (card?.status === "wrong") {
      el.classList.add("wrong");
      el.querySelector(".symbol").textContent = "×";
    }
  }

  $("queueCount").textContent = state.queue.length;
  $("queue").innerHTML = "";
  state.queue.forEach(item => {
    const li = document.createElement("li");
    li.textContent = "@" + item.username;
    $("queue").appendChild(li);
  });

  $("history").innerHTML = "";
  if (!state.history.length) {
    $("history").textContent = "Пока нет завершённых раундов";
    $("history").className = "history-empty";
  } else {
    $("history").className = "";
    state.history.forEach(item => {
      const row = document.createElement("div");
      row.className = "history-item";
      const name = document.createElement("span");
      name.textContent = "@" + item.username;
      const result = document.createElement("span");
      result.textContent = item.result === "ПОБЕДА" ? "ПОБЕДА" : `${item.correct}/10`;
      result.className = item.result === "ПОБЕДА" ? "win" : "";
      row.append(name, result);
      $("history").appendChild(row);
    });
  }
});
