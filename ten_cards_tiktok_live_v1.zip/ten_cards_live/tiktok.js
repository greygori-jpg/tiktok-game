// TikTok LIVE comment adapter.
// Uses an unofficial community connector; TikTok may change the underlying protocol.
import { TikTokLiveConnection, WebcastEvent, ControlEvent } from "tiktok-live-connector";

export function connectTikTok({ username, onComment, onStatus }) {
  if (!username) {
    onStatus?.("TikTok username is not configured. Demo mode only.");
    return null;
  }

  const connection = new TikTokLiveConnection(username.replace(/^@/, ""));

  connection.on(ControlEvent.ERROR, ({ info, exception }) => {
    onStatus?.(`TikTok connection error: ${info || exception?.message || "unknown"}`);
  });

  connection.on(WebcastEvent.CHAT, (event) => {
    const displayName = event.user?.displayId || event.user?.nickname || "unknown";
    const content = String(event.content || "").trim();
    if (content) onComment({ username: displayName, content });
  });

  connection.connect()
    .then(state => onStatus?.(`Connected to TikTok LIVE room ${state.roomId}`))
    .catch(error => onStatus?.(`Could not connect to TikTok LIVE: ${error.message}`));

  return connection;
}
