// Game engine: one shared queue, one active player, 10 attempts per turn.
export class TenCardsGame {
  constructor({ emitState = () => {}, onLog = () => {} } = {}) {
    this.emitState = emitState;
    this.onLog = onLog;
    this.queue = [];
    this.active = null;
    this.history = [];
    this.roundNumber = 0;
    this.lastMessage = "Ожидаем первого игрока. Напиши ИГРА в комментариях.";
    this.startNextIfNeeded();
  }

  normalizeName(name) {
    return String(name || "unknown").trim().replace(/^@/, "").slice(0, 40);
  }

  join(name) {
    const username = this.normalizeName(name);
    if (!username || username === "unknown") return;
    if (this.active?.username.toLowerCase() === username.toLowerCase()) {
      this.lastMessage = `@${username}, ты уже играешь. Выбирай карту от 1 до 10.`;
      this.publish();
      return;
    }
    if (this.queue.some(p => p.username.toLowerCase() === username.toLowerCase())) {
      this.lastMessage = `@${username}, ты уже в очереди.`;
      this.publish();
      return;
    }
    this.queue.push({ username, joinedAt: Date.now() });
    this.lastMessage = `@${username} добавлен в очередь. Место: ${this.queue.length + (this.active ? 1 : 0)}.`;
    this.onLog("JOIN", username);
    this.startNextIfNeeded();
    this.publish();
  }

  choose(name, rawNumber) {
    const username = this.normalizeName(name);
    const number = Number(String(rawNumber).trim());
    if (!Number.isInteger(number) || number < 1 || number > 10) return;
    if (!this.active || this.active.username.toLowerCase() !== username.toLowerCase()) {
      if (this.queue.some(p => p.username.toLowerCase() === username.toLowerCase())) {
        this.lastMessage = `@${username}, дождись своей очереди.`;
        this.publish();
      }
      return;
    }

    if (this.active.attempts >= 10) return;
    this.active.attempts += 1;

    const expected = this.active.order[this.active.progress];
    if (number === expected) {
      this.active.opened.push(number);
      this.active.progress += 1;
      this.active.lastResult = { number, correct: true };
      this.lastMessage = `@${username} открыл правильную карту! ${this.active.progress}/10`;
      this.onLog("CORRECT", `${username}: ${number}`);
    } else {
      this.active.lastResult = { number, correct: false };
      this.lastMessage = `@${username} выбрал ${number}. Это ошибка. Попыток: ${this.active.attempts}/10.`;
      this.onLog("WRONG", `${username}: ${number}`);
    }

    if (this.active.progress === 10) {
      this.finish("ПОБЕДА");
      return;
    }
    if (this.active.attempts >= 10) {
      this.finish("10 ПОПЫТОК ИСЧЕРПАНО");
      return;
    }
    this.publish();
  }

  finish(result) {
    if (!this.active) return;
    const finished = {
      username: this.active.username,
      result,
      attempts: this.active.attempts,
      correct: this.active.progress,
      at: Date.now()
    };
    this.history.unshift(finished);
    this.history = this.history.slice(0, 10);
    this.lastMessage = result === "ПОБЕДА"
      ? `🏆 @${finished.username} ПОБЕДИЛ!`
      : `Раунд @${finished.username} завершён: ${finished.correct}/10 правильных.`;
    this.onLog("FINISH", `${finished.username}: ${result}`);
    this.active = null;
    this.startNextIfNeeded();
    this.publish();
  }

  startNextIfNeeded() {
    if (this.active || this.queue.length === 0) {
      if (!this.active && this.queue.length === 0) {
        this.lastMessage = "Очередь пуста. Напиши ИГРА, чтобы присоединиться.";
      }
      this.publish();
      return;
    }
    const next = this.queue.shift();
    this.roundNumber += 1;
    const order = this.shuffle([1,2,3,4,5,6,7,8,9,10]);
    this.active = {
      username: next.username,
      attempts: 0,
      progress: 0,
      order,
      opened: [],
      lastResult: null,
      round: this.roundNumber
    };
    this.lastMessage = `🎮 @${next.username}, твой ход! Напиши номер карты от 1 до 10.`;
    this.onLog("START", next.username);
    this.publish();
  }

  shuffle(items) {
    const a = [...items];
    for (let i = a.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
  }

  publicState() {
    return {
      active: this.active ? {
        username: this.active.username,
        attempts: this.active.attempts,
        progress: this.active.progress,
        opened: this.active.opened,
        lastResult: this.active.lastResult,
        round: this.active.round
      } : null,
      queue: this.queue.map((p, i) => ({ username: p.username, position: i + 1 })),
      history: this.history,
      roundNumber: this.roundNumber,
      lastMessage: this.lastMessage,
      cards: Array.from({ length: 10 }, (_, i) => {
        const n = i + 1;
        return {
          position: n,
          status: this.active?.opened.includes(n) ? "opened" :
            (this.active?.lastResult?.number === n && !this.active?.lastResult?.correct ? "wrong" : "closed")
        };
      })
    };
  }

  publish() {
    this.emitState(this.publicState());
  }
}
