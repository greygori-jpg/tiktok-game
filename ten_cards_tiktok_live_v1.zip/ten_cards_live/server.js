import express from "express";
import http from "http";
import { Server } from "socket.io";
import dotenv from "dotenv";
import { TenCardsGame } from "./game.js";
import { connectTikTok } from "./tiktok.js";

dotenv.config();

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static("public"));
app.get("/health", (_req, res) => res.json({ ok: true, service: "ten-cards-live" }));

const game = new TenCardsGame({
  emitState: state => io.emit("game:state", state),
  onLog: (type, detail) => console.log(`[${type}] ${detail}`)
});

function handleComment({ username, content }) {
  const command = content.trim();
  if (/^(игра|play|join)$/i.test(command)) {
    game.join(username);
    return;
  }
  if (/^(?:карта\s*)?([1-9]|10)$/i.test(command)) {
    const match = command.match(/([1-9]|10)$/);
    game.choose(username, match[1]);
  }
}

let tiktokConnection = null;
if (process.env.TIKTOK_USERNAME) {
  tiktokConnection = connectTikTok({
    username: process.env.TIKTOK_USERNAME,
    onComment: handleComment,
    onStatus: message => console.log(`[TIKTOK] ${message}`)
  });
} else {
  console.log("[TIKTOK] Demo mode: set TIKTOK_USERNAME in environment to connect.");
}

// Demo commands let you test the game before connecting TikTok.
app.post("/demo/comment", express.json(), (req, res) => {
  const username = String(req.body?.username || "demo_viewer");
  const content = String(req.body?.content || "");
  handleComment({ username, content });
  res.json({ ok: true, state: game.publicState() });
});

io.on("connection", socket => {
  socket.emit("game:state", game.publicState());
});

const port = Number(process.env.PORT || 3000);
server.listen(port, () => console.log(`Ten Cards LIVE server listening on ${port}`));

process.on("SIGINT", async () => {
  if (tiktokConnection) await tiktokConnection.disconnect().catch(() => {});
  process.exit(0);
});
